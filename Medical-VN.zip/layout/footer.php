<footer>
  <div class="container">
    <div class="logo">
      <a class="logo__footer" href="">Medical-VN</a>
      <div class="time" style="padding-left:50%;">
        <a href="https://time.is/Vietnam" id="time_is_link" rel="nofollow"></a>
        <span id="Vietnam_z418" style="font-size:40px"></span>
        <script src="//widget.time.is/t.js"></script>
        <script>
          time_is_widget.init({
            Vietnam_z418: {}
          });
        </script>
      </div>
    </div>
    <div class="link">
      <div class="col">
        <a href="">Về Medical-VN</a>
        <p>Tại MedicalVN, chúng tôi luôn tận tâm phục vụ và
          được đào tạo để hoàn thành xuất sắc những sứ mệnh
          được giao.</p>
        <!-- <a href=""></a> -->
        <!-- <a href="https://dangthanh.site">____</a> -->
        <p class="copyright-notice">©2022 MedicalVN</p>
      </div>
      <div class="col">
        <ul>
          <li><a href="">Nhiệt kế</a> </li>
          <li><a href="">Máy đo huyết áp</a> </li>
          <li><a href="">Thiết bị kiểm tra</a> </li>
        </ul>
      </div>
      <div class="col">
        <ul>
          <li><a href="">Trung tâm hỗ trợ</a></li>
          <li><a href="">Câu hỏi thường gặp</a></li>
        </ul>
      </div>
      <div class="col">
        <ul>
          <li><a href="./member.php">Liên hệ</a></li>
          <li><a href="./member.php">Thành viên</a></li>
        </ul>
      </div>
      <div class="icon">
        <a href="./member.php" target="_blank"><i class="fa-brands fa-facebook"></i></a>
        <a href="./member.php"><i class="fa-brands fa-instagram"></i></a>
        <a href="./member.php"><i class="fa-brands fa-twitter"></i></a>
      </div>
    </div>
    <!-- <div class="bottom">
      <a href=""><img src="images/icon/logo-playstore.svg" alt=""></a>
      <a href=""><img src="images/icon/logo-appstore.svg" alt=""></a>
    </div> -->
  </div>
</footer>
<style>
</style>